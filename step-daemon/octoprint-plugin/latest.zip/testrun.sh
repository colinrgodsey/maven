#!/bin/bash

VENV="/Users/colin/.virtualenvs/OctoPrint"

cd /Users/colin/Dropbox/printserver/octoprint-plugin

$VENV/bin/octoprint dev plugin:install

cd $VENV

#./bin/octoprint serve

